// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package scrape

import (
	"context"
	"crypto/tls"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"testing"
	"time"

	config_util "github.com/prometheus/common/config"
	"github.com/prometheus/common/model"
	"github.com/stretchr/testify/require"

	"github.com/prometheus/prometheus/config"
	"github.com/prometheus/prometheus/model/labels"
)

func TestScrapeClientForTargetUnixSocket(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Unix sockets are not supported on Windows.")
	}

	const advertisedAddress = "prometheus.rocks:8443"

	httpHost := make(chan string, 1)
	httpHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		httpHost <- r.Host
		w.Header().Set("Content-Type", "text/plain; version=0.0.4")
		_, _ = io.WriteString(w, "unix_metric 1\n")
	})

	httpSocket := startUnixHTTPServer(t, nil, httpHandler)
	httpTarget := newUnixSocketTarget("http", advertisedAddress, httpSocket)
	httpClient, err := newScrapeClientForTarget(
		config_util.DefaultHTTPClientConfig,
		"test",
		http.DefaultClient,
		httpTarget,
	)
	require.NoError(t, err)
	httpScraper := &targetScraper{
		Target: &Target{labels: httpTarget, scrapeConfig: &config.ScrapeConfig{}},
		client: httpClient,
	}
	require.Equal(t, "unix_metric 1\n", scrapeTargetBody(t, httpScraper))
	require.Equal(t, advertisedAddress, <-httpHost)

	httpsHost := make(chan string, 1)
	gotSNI := make(chan string, 1)
	httpsHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		httpsHost <- r.Host
		w.Header().Set("Content-Type", "text/plain; version=0.0.4")
		_, _ = io.WriteString(w, "unix_metric 1\n")
	})
	httpsSocket := startUnixHTTPServer(t, &tls.Config{
		Certificates: mustLoadTestCertificate(t),
		GetConfigForClient: func(info *tls.ClientHelloInfo) (*tls.Config, error) {
			gotSNI <- info.ServerName
			return nil, nil
		},
	}, httpsHandler)
	httpsTarget := newUnixSocketTarget("https", advertisedAddress, httpsSocket)
	httpsClient, err := newScrapeClientForTarget(
		config_util.HTTPClientConfig{
			TLSConfig: config_util.TLSConfig{CAFile: caCertPath},
		},
		"test",
		http.DefaultClient,
		httpsTarget,
	)
	require.NoError(t, err)
	httpsScraper := &targetScraper{
		Target: &Target{labels: httpsTarget, scrapeConfig: &config.ScrapeConfig{}},
		client: httpsClient,
	}
	require.Equal(t, "unix_metric 1\n", scrapeTargetBody(t, httpsScraper))
	require.Equal(t, advertisedAddress, <-httpsHost)
	require.Equal(t, "prometheus.rocks", <-gotSNI)
}

func TestScrapeClientForTargetUnixSocketIsolation(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Unix sockets are not supported on Windows.")
	}

	const advertisedAddress = "exporter.example:8080"

	var (
		gotHostsA = make(chan string, 1)
		gotHostsB = make(chan string, 1)
	)
	socketA := startUnixHTTPServer(t, nil, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotHostsA <- r.Host
		_, _ = io.WriteString(w, "socket_a_metric 1\n")
	}))
	socketB := startUnixHTTPServer(t, nil, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotHostsB <- r.Host
		_, _ = io.WriteString(w, "socket_b_metric 1\n")
	}))

	baseClient, err := newScrapeClient(config_util.DefaultHTTPClientConfig, "test")
	require.NoError(t, err)
	sp := &scrapePool{
		config:  &config.ScrapeConfig{JobName: "test", HTTPClientConfig: config_util.DefaultHTTPClientConfig},
		options: &Options{},
		client:  baseClient,
	}
	targetA := newUnixSocketTarget("http", advertisedAddress, socketA)
	targetB := newUnixSocketTarget("http", advertisedAddress, socketB)
	clientA, err := sp.scrapeClientForTarget(&Target{labels: targetA})
	require.NoError(t, err)
	clientB, err := sp.scrapeClientForTarget(&Target{labels: targetB})
	require.NoError(t, err)
	require.NotSame(t, clientA, clientB)

	scraperA := &targetScraper{
		Target: &Target{labels: targetA, scrapeConfig: &config.ScrapeConfig{}},
		client: clientA,
	}
	scraperB := &targetScraper{
		Target: &Target{labels: targetB, scrapeConfig: &config.ScrapeConfig{}},
		client: clientB,
	}

	require.Equal(t, "socket_a_metric 1\n", scrapeTargetBody(t, scraperA))
	require.Equal(t, "socket_b_metric 1\n", scrapeTargetBody(t, scraperB))
	require.Equal(t, advertisedAddress, <-gotHostsA)
	require.Equal(t, advertisedAddress, <-gotHostsB)
}

func TestScrapeClientForTargetUnixSocketNoTCPFallback(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Unix sockets are not supported on Windows.")
	}

	tcpListener, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	t.Cleanup(func() { _ = tcpListener.Close() })

	tcpHit := make(chan struct{}, 1)
	server := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		tcpHit <- struct{}{}
		_, _ = io.WriteString(w, "tcp_metric 1\n")
	})}
	go func() { _ = server.Serve(tcpListener) }()
	t.Cleanup(func() { _ = server.Close() })

	target := newUnixSocketTarget("http", tcpListener.Addr().String(), filepath.Join(t.TempDir(), "missing.sock"))
	client, err := newScrapeClientForTarget(config_util.DefaultHTTPClientConfig, "test", http.DefaultClient, target)
	require.NoError(t, err)
	scraper := &targetScraper{
		Target: &Target{labels: target, scrapeConfig: &config.ScrapeConfig{}},
		client: client,
	}

	_, err = scraper.scrape(context.Background())
	require.Error(t, err)
	select {
	case <-tcpHit:
		t.Fatal("scrape fell back to TCP after the Unix socket dial failed")
	default:
	}

	tcpTarget := labels.FromStrings(
		model.SchemeLabel, "http",
		model.AddressLabel, tcpListener.Addr().String(),
		model.MetricsPathLabel, "/metrics",
	)
	tcpClient, err := newScrapeClientForTarget(config_util.DefaultHTTPClientConfig, "test", http.DefaultClient, tcpTarget)
	require.NoError(t, err)
	require.Same(t, http.DefaultClient, tcpClient)

	emptySocketTarget := newUnixSocketTarget("http", tcpListener.Addr().String(), "")
	_, err = newScrapeClientForTarget(config_util.DefaultHTTPClientConfig, "test", http.DefaultClient, emptySocketTarget)
	require.Error(t, err)
}

func newUnixSocketTarget(scheme, address, socket string) labels.Labels {
	return labels.FromStrings(
		model.SchemeLabel, scheme,
		model.AddressLabel, address,
		model.MetricsPathLabel, "/metrics",
		unixSocketLabel, socket,
	)
}

func scrapeTargetBody(t *testing.T, scraper *targetScraper) string {
	t.Helper()
	resp, err := scraper.scrape(t.Context())
	require.NoError(t, err)
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	require.NoError(t, err)
	return string(body)
}

func startUnixHTTPServer(t *testing.T, tlsConfig *tls.Config, handler http.Handler) string {
	t.Helper()
	socket := filepath.Join(t.TempDir(), "metrics.sock")
	listener, err := net.Listen("unix", socket)
	require.NoError(t, err)
	if tlsConfig != nil {
		listener = tls.NewListener(listener, tlsConfig)
	}

	server := &http.Server{Handler: handler}
	go func() { _ = server.Serve(listener) }()
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		_ = server.Shutdown(ctx)
		cancel()
		_ = server.Close()
		_ = listener.Close()
		_ = os.Remove(socket)
	})
	return socket
}

func mustLoadTestCertificate(t *testing.T) []tls.Certificate {
	t.Helper()
	certificate, err := tls.LoadX509KeyPair("testdata/servername.cer", "testdata/servername.key")
	require.NoError(t, err)
	return []tls.Certificate{certificate}
}
