// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package scrape

import (
	"context"
	"errors"
	"net"
	"net/http"

	config_util "github.com/prometheus/common/config"

	"github.com/prometheus/prometheus/model/labels"
)

const unixSocketLabel = "__unix_socket__"

func (sp *scrapePool) scrapeClientForTarget(target *Target) (*http.Client, error) {
	return newScrapeClientForTarget(
		sp.config.HTTPClientConfig,
		sp.config.JobName,
		sp.client,
		target.labels,
		sp.options.HTTPClientOptions...,
	)
}

// NewScrapeClientForTarget returns the scrape client for target. Targets that
// specify a Unix socket get a client with a transport dedicated to that socket.
// This prevents the HTTP transport from reusing a connection belonging to a
// different target with the same advertised address.
func newScrapeClientForTarget(
	cfg config_util.HTTPClientConfig,
	name string,
	baseClient *http.Client,
	target labels.Labels,
	optFuncs ...config_util.HTTPClientOption,
) (*http.Client, error) {
	if !target.Has(unixSocketLabel) {
		return baseClient, nil
	}

	socket := target.Get(unixSocketLabel)
	if socket == "" {
		return nil, errors.New("unix socket label is empty")
	}

	// A Unix socket is local to the Prometheus process. In particular, do not
	// allow a configured proxy to turn a failed Unix dial into a TCP request.
	cfg.ProxyConfig = config_util.ProxyConfig{}

	// Keep the caller's options, but make the socket dialer authoritative. The
	// transport is target-specific, so disabling keep-alives also avoids leaving
	// idle socket connections behind when targets are removed or reloaded.
	dialer := &net.Dialer{}
	targetOpts := append([]config_util.HTTPClientOption(nil), optFuncs...)
	targetOpts = append(targetOpts,
		config_util.WithDialContextFunc(func(ctx context.Context, _, _ string) (net.Conn, error) {
			return dialer.DialContext(ctx, "unix", socket)
		}),
		config_util.WithKeepAlivesDisabled(),
	)

	return newScrapeClient(cfg, name, targetOpts...)
}
